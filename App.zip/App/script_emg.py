import numpy as np
import pandas as pd
import re
from scipy.signal import butter, filtfilt, correlate
import matplotlib.pyplot as plt
import os
from concurrent.futures import ThreadPoolExecutor

def get_emg_signal(csv_path):
    
    
    def bandpass_filter(emg, lowcut=50.0, highcut=300.0, fs=2000.0, butter_order=4):
        """Efficient bandpass filter applied to the EMG signal."""
        nyquist = 0.5 * fs
        low = lowcut / nyquist
        high = highcut / nyquist
        b, a = butter(butter_order, [low, high], btype='band')
        return filtfilt(b, a, emg)
    
    def smooth_envelope(emg, smooth_ms=500.0, fs=2000.0):
        """Efficient smoothing using a moving average."""
        smooth_samples = int(smooth_ms / 1000 * fs)
        return np.abs(correlate(emg, np.ones(smooth_samples)/smooth_samples, mode='same'))
    
    def process_channel(emg, fs=2000.0, lowcut=50.0, highcut=300.0, smooth_ms=500.0, use_tkeo=True):
        """Process a single EMG channel (filter, envelope, and smooth)."""
        emg_filtered = bandpass_filter(emg, lowcut, highcut, fs)
    
        if use_tkeo:
            emg_tkeo = np.diff(emg_filtered)**2
            emg_envelope = np.abs(emg_tkeo)
        else:
            emg_envelope = np.abs(emg_filtered)
    
        smoothed_envelope = smooth_envelope(emg_envelope, smooth_ms, fs)
        t = np.arange(len(smoothed_envelope)) / fs
        return smoothed_envelope, t
    
    def get_smoothed_emg_multi(csv_path, fs=2000.0, lowcut=50.0, highcut=300.0, smooth_ms=500.0, use_tkeo=True, encoding_try=("utf-8-sig", "utf-8", "latin1", "ISO-8859-1")):
        """Process all EMG columns from the CSV and apply the envelope extraction."""
        df = None
        last_err = None
    
        for enc in encoding_try:
            try:
                df = pd.read_csv(csv_path, encoding=enc)
                break
            except Exception as e:
                last_err = e
                print(f"Failed to read CSV with encoding {enc}: {e}")
        
        if df is None:
            raise RuntimeError(f"Failed to read CSV with encodings {encoding_try}. Last error: {last_err}")
    
        time_col = None
        for col in df.columns:
            if re.search(r'(?i)^time', str(col)):
                time_col = col
                break
        if time_col is not None:
            t = pd.to_numeric(df[time_col], errors="coerce").to_numpy()
        else:
            raise ValueError("No time column found in the CSV")
        
        emg_cols = [col for col in df.columns if re.search(r'(?i)^emg', str(col))]
        
        envelopes = []
        for emg_col in emg_cols:
            emg = df[emg_col].to_numpy()
            smoothed_envelope, t_ = process_channel(emg, fs, lowcut, highcut, smooth_ms, use_tkeo)
            envelopes.append(smoothed_envelope)
            if len(t) != len(t_):
                t = t_
    
        return t, envelopes, emg_cols
    
    def plot_emg_envelopes(t, envelopes, labels):
        """Plot the processed EMG envelopes in different subplots."""
        num_emgs = len(envelopes)
        fig, axes = plt.subplots(num_emgs, 1, figsize=(12, 6 * num_emgs))
    
        if num_emgs == 1:
            axes = [axes]
    
        for i, (envelope, ax) in enumerate(zip(envelopes, axes)):
            ax.plot(t, envelope, label=f"EMG {labels[i]}")
            ax.set_title(f"Smoothed EMG {labels[i]}")
            ax.set_xlabel("Time (s)")
            ax.set_ylabel("Amplitude")
            ax.legend()
            ax.grid(True)
    
        plt.tight_layout()
        plt.show()
    
    def process_emg_csv(csv_path, plot=False):
        """Process an EMG CSV, compute smoothed envelopes, and optionally plot results."""
        t, envelopes, labels = get_smoothed_emg_multi(csv_path)
    
        print("Time vector:", t[:5])  # Show first 5 time values
        print("First envelope for each EMG column:", [env[:5] for env in envelopes])  # Show first 5 values of each envelope
        print("EMG Labels:", labels)  # Print labels (EMG column names)
    
        if plot:
            plot_emg_envelopes(t, envelopes, labels)
    
        return t, envelopes, labels
    
    def save_emg_results_to_csv(t, envelopes, labels, output_path="processed_emg_results.csv"):
        """Save the processed EMG data to a new CSV."""
        result_df = pd.DataFrame(np.column_stack([t] + envelopes), columns=["Time"] + labels)
        result_df.to_csv(output_path, index=False)
        print(f"Processed EMG results saved to {output_path}")
    
    def main():
        import argparse
    
        parser = argparse.ArgumentParser(description="Process EMG CSV and plot envelopes")
        parser.add_argument("csv_file", help="Path to the input EMG CSV file")
        parser.add_argument("--plot", action="store_true", help="Plot the EMG envelopes")
        parser.add_argument("--save", action="store_true", help="Save processed results to CSV")
        parser.add_argument("--output", default="processed_emg_results.csv", help="Output CSV file path")
        
        args = parser.parse_args()
    
        t, envelopes, labels = process_emg_csv(args.csv_file, plot=args.plot)
        
        if args.save:
            save_emg_results_to_csv(t, envelopes, labels, output_path=args.output)
    
    if __name__ == "__main__":
        main()
