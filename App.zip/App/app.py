import pygame
import math
from ellipse_exceedance import analyze_trials
from wavex_sdk import get_sensor_data
from script_emg import get_emg_signal

# pygame setup
pygame.init()
screen_shape = (1280,720)
screen = pygame.display.set_mode(screen_shape)
clock = pygame.time.Clock()
running = True
dt = 0
start_time = pygame.time.get_ticks()

root = r"C:\Users\Utilizador\Documents\Pedro\Universidade\5 Ano - 1 Semestre\DDM\Challenge"


background_main = pygame.image.load(root + "\Images\main.png")
background_main_pos = pygame.Vector2(0, 0)

background_default = pygame.image.load(root + "\Images\default.png")
background_default = pygame.transform.scale(background_default, screen_shape)
background_default_pos = pygame.Vector2(0, 0)

equilisense = pygame.image.load(root + "\Images\equilisense.png")
equilisense_pos = pygame.Vector2(70, 70)
angle_amplitude = 4      
rotation_speed = 0.4 
angle_phase = 0.0 


logo = pygame.image.load(root + "\Images\sempre_em_pe.png")
logo_pos = pygame.Vector2(800, 200)

background_blank = pygame.image.load(root + r"\Images\background_blank.png")
background_blank = pygame.transform.scale(background_blank, (1280, 720))
background_blank_pos = pygame.Vector2(0, 0)

main_blue = [9, 158, 224]
transparent_blue = [230, 245, 252]
white = [255, 255, 255]
main_border_radius = 10

#****MAIN PAGE****#

blue_background_rectangle = [1280, 720, 0, 0]
white_background_rectangle = [1280-80, 720-80, 40, 40]

button_font = pygame.font.Font(root + "\Images\Images\\arial-mt-pro-regular.otf", 35)
button_1_text = button_font.render('Start Balance Session', True, "WHITE")
button_1_text_pos = pygame.Vector2(100,400)
button_1_position = [90, 390, 375, 50]


#****INFORMATION PAGE****#

blue_rectangle_pos = [90, 215, 700, 400]

info_title_font = pygame.font.Font(root + "\Images\\arial-mt-pro-regular.otf", 38)
info_title_text = info_title_font.render('Fill Patient Data', True, "WHITE")
info_title_text_pos = pygame.Vector2(100,225)

info_text_font = pygame.font.Font(root + "\Images\\arial-mt-pro-regular.otf", 35)

input_boxes = [[100, 300, 600, 55], [100, 365, 600, 55], [100, 430, 600, 55], [100, 495, 600, 55]]
input_texts = ['Name', 'Date of Birth', 'Sex', 'New patient? (Yes/No)']
file_name = ''
input_bools = [True, False, False, False]
box_count = 0
changed = False
t_delay = 0

     

#****CALIBRATION MENU****#

calibration_rectangle_pos = [390, 300, 500, 60]
recording_rectangle_pos = [390, 370, 500, 60]

recording_menu_font = pygame.font.Font(root + "\Images\\arial-mt-pro-regular.otf", 38)

calibration_text = recording_menu_font.render('Start Calibration', True, "White")
calibration_text_pos = pygame.Vector2(500, 315)

recording_text = recording_menu_font.render('Start Recording', True, "White")
recording_text_pos = pygame.Vector2(500, 385)

rep_calibration_text = recording_menu_font.render('Repeat Calibration', True, "White")
rep_calibration_text_pos = pygame.Vector2(480, 315)


#****CALIBRATION - MEASURE HEIGHT****#

lumbar_region = pygame.image.load(root + "\Images\lumbar_region.png") #2279x1033
lumbar_region = pygame.transform.scale(lumbar_region, (2279/4, 1033/4))
lumbar_region_pos = pygame.Vector2(412, 315)


height_title_font = pygame.font.Font(root + "\Images\\arial-mt-pro-regular.otf", 45)

height_title_text = height_title_font.render('1 - Lumbar Sensor Height', True, "White")
height_title_pos = pygame.Vector2(100, 200)
height_title_rec = [100-10, 200-15, 550, 70]


height_desc_font = pygame.font.Font(root + "\Images\\arial-mt-pro-regular.otf", 25)
height_desc_text = height_desc_font.render('Assess the height of the lumbar session (in centimeters).', True, 'Black')
height_desc_pos = pygame.Vector2(100, 265)

input_height_box = [450, 600, 300, 55]
input_height_text = 'Sensor height'


#****CALIBRATION - 30 SECS NORMAL****#

standing = pygame.image.load(root + r"\Images\balance_position.jpg") #171x364
standing = pygame.transform.scale(standing, (171*1.2,364*1.2))
standing_pos = pygame.Vector2(850, 200)

standing_title_text = height_title_font.render('2 - Standing Calibration', True, "White")
standing_title_pos = pygame.Vector2(100, 200)
standing_title_rec = [100-10, 200-15, 500, 70]

instructions_title = "Instructions"
instructions = ["1 - Take your shoes off.", "2 - Copy the position on the image.", "3 - Stand still looking at a fixed point.", "4 - The calibration will be 30 seconds."]

start_calibration_button = [310, 525, 300, 60]
start_calibration_text = info_text_font.render('RECORD', True, "White")
start_calibration_text_pos = pygame.Vector2(310+77, 525+17)


instructions_title_text = info_text_font.render(instructions_title, True, 'Black')
instructions_title_pos = pygame.Vector2(100, 280)

# instructions_text = height_desc_font.render(instructions, True, 'Black')
# instructions_text_pos = pygame.Vector2(100, 300)


#****CALIBRATION - LIMITS OF STABILITY****#

limits_of_stability = pygame.image.load(root + "\Images\limits_of_stability.png") #638x382
limits_of_stability = pygame.transform.scale(limits_of_stability, (638/1.5, 382/1.5))
limits_of_stability_pos = pygame.Vector2(750, 300)

limits_of_stability_text = height_title_font.render('3 - Limits of Stability Calibration', True, "White")
limits_of_stability_text_pos = pygame.Vector2(100, 200)
limits_of_stability_rec = [100-10, 200-15, 660, 70]

instructions_standing = ["1 - You will lean until you are on the edge of stability.", "2 - The clinician will tell which direction to lean.", "3 - The calibration will be 30 seconds."]



#****RECORDING****#

recording_title_text = height_title_font.render('Recording', True, "White")
recording_title_pos = pygame.Vector2(100, 200)
recording_title_rec = [100-10, 200-15, 230, 70]


recording_string = "The calibration is done. You can start recording."

start_recording_text = height_desc_font.render(recording_string, True, 'Black')
start_recording_text_pos = pygame.Vector2(100, 280)

record_rectangle_pos = [400, 400, 500, 100]
record_button_text = recording_menu_font.render("RECORD", True, "White")
record_button_pos = pygame.Vector2(560, 435)


#****BALANCE INDEX****#

balance_score = pygame.image.load(root + r"\Results\balance_score.png") #600x400
balance_score_pos = (350, 150)

other_results_rectangle_pos = [390, 550, 500, 70]
other_results_button_text = info_title_font.render("See other results", True, "White")
other_results_button_pos = pygame.Vector2(500, 570)



#****RESULTS MENU****#

elipsis_los_rectangle_pos = [390, 230, 500, 60]
com_displacement_time_rectangle_pos = [390, 300, 500, 60]
com_displacement_top_view_rectangle_pos = [390, 370, 500, 60]
emg_plot_rectangle_pos = [390, 440, 500, 60]
roll_and_pitch_rectangle_pos = [390, 510, 500, 60]



elipsis_los_text = recording_menu_font.render('Balance Elipsis', True, "White")
elipsis_los_text_pos = pygame.Vector2(520, 245)

com_displacement_time_text = info_text_font.render('CoM Displacement Over Time', True, "White")
com_displacement_time_text_pos = pygame.Vector2(400, 315)

com_displacement_top_view_text = info_text_font.render('CoM Displacement Top View', True, "White")
com_displacement_top_view_text_pos = pygame.Vector2(415, 385)

emg_plot_text = recording_menu_font.render('EMG Plot Over Time', True, "White")
emg_plot_text_pos = pygame.Vector2(470, 455)

roll_and_pitch_text = recording_menu_font.render('Roll and Pitch Angles', True, "White")
roll_and_pitch_text_pos = pygame.Vector2(460, 525)



elipsis_los = pygame.image.load(root + r"\Results\elipsis_los.png") #794x785
elipsis_los = pygame.transform.scale(elipsis_los, (794*0.6,785*0.6))
elipsis_los_pos = pygame.Vector2(200, 200)

com_displacement_time = pygame.image.load(root + r"\Results\com_displacement_time.png") #1464x785
com_displacement_time = pygame.transform.scale(com_displacement_time, (1464*.5,785*.5))
com_displacement_time_pos = pygame.Vector2(200, 200)

com_displacement_top_view = pygame.image.load(root + r"\Results\com_displacement_top_view.png") #996x1006
com_displacement_top_view = pygame.transform.scale(com_displacement_top_view, (996*.5,1006*.5))
com_displacement_top_view_pos = pygame.Vector2(200, 200)

emg_plot = pygame.image.load(root + r"\Results\emg_trial.png") #1489x437
emg_plot = pygame.transform.scale(emg_plot, (1489*0.6,437*0.6))
emg_plot_pos = pygame.Vector2(200, 200)

roll_and_pitch_ot = pygame.image.load(root + r"\Results\roll_and_pitch_angles.png") #1451x785
roll_and_pitch_ot = pygame.transform.scale(roll_and_pitch_ot, (1451*.5,785*.5))
roll_and_pitch_ot_pos = pygame.Vector2(200, 200)

results_menu_plots = [elipsis_los, com_displacement_time, com_displacement_top_view, emg_plot, roll_and_pitch_ot]
results_menu_plots_pos= [(400, 170), (270, 200), (380, 170), (200, 250), (250, 200)]

balance_index = round(((1-67.4/100)*0.7 + 0.3*(1-48.2/100))*100,2)

back_rectangle_pos = [1040, 550, 150, 60]
back_text = recording_menu_font.render('Back', True, 'White') 
back_text_pos = (1040+35, 550+15)



#****BOOLEANS TO PASS BETWEEN PAGES****#


bool_main = True
bool_starting_session = False
bool_recording_menu = False
bool_calibrating_1 = False
bool_calibrating_2 = False
bool_calibrating_3 = False
bool_recording = False
bool_balance_result = False
bool_results_menu = False
show_plot = False

results_bools = [False, False, False, False, False]


calibrated = False
inside_button = False
got_results = True

pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_ARROW)


while running:
    
    mouse_pos = pygame.mouse.get_pos()
    
    
    # poll for events
    # pygame.QUIT event means the user clicked X to close your window
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            
            
        #PRESSING THE MOUSE#
        
        if event.type == pygame.MOUSEBUTTONDOWN:
           
            
            if bool_main == True:
                left_bound = button_1_position[0]
                right_bound = button_1_position[0] + button_1_position[2]
                up_bound = button_1_position[1]
                down_bound = button_1_position[1] + button_1_position[3]
                if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
                    bool_main = False
                    bool_starting_session = True
                    
                    
            elif bool_recording_menu == True:
                left_bound_cal = calibration_rectangle_pos[0]
                right_bound_cal = calibration_rectangle_pos[0] + calibration_rectangle_pos[2]
                up_bound_cal = calibration_rectangle_pos[1]
                down_bound_cal = calibration_rectangle_pos[1] + calibration_rectangle_pos[3]
                if left_bound_cal < mouse_pos[0] < right_bound_cal and up_bound_cal < mouse_pos[1] < down_bound_cal:
                    calibrated = False
                    bool_recording_menu = False
                    bool_calibrating_1 = True 
                    
                if calibrated == True:
                    left_bound_rec = recording_rectangle_pos[0]
                    right_bound_rec = recording_rectangle_pos[0] + recording_rectangle_pos[2]
                    up_bound_rec = recording_rectangle_pos[1]
                    down_bound_rec = recording_rectangle_pos[1] + recording_rectangle_pos[3]
                    if left_bound_rec < mouse_pos[0] < right_bound_rec and up_bound_rec < mouse_pos[1] < down_bound_rec:
                        bool_recording_menu = False
                        bool_recording = True
                        t_delay_mouse = pygame.time.get_ticks()
                    
                    
            elif bool_calibrating_2 == True:
                left_bound = start_calibration_button[0]
                right_bound = start_calibration_button[0] + start_calibration_button[2]
                up_bound = start_calibration_button[1]
                down_bound = start_calibration_button[1] + start_calibration_button[3]
                if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
                    bool_calibrating_2 = False
                    bool_calibrating_3 = True 
                    t_delay_mouse = pygame.time.get_ticks()
                    get_sensor_data(root, f"{file_name}_standing_stability")
                   
            elif bool_calibrating_3 == True and pygame.time.get_ticks() > t_delay_mouse+ 200:
                
                left_bound = start_calibration_button[0]
                right_bound = start_calibration_button[0] + start_calibration_button[2]
                up_bound = start_calibration_button[1]
                down_bound = start_calibration_button[1] + start_calibration_button[3]
                if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
                    #print('here')
                    bool_calibrating_3 = False
                    bool_recording_menu = True
                    input_height_text = 'Sensor height'
                    calibrated = True
                    get_sensor_data(root, f"{file_name}_limits_of_stability")
                    
                    
            elif bool_recording == True and pygame.time.get_ticks() > t_delay_mouse + 200:
                
                left_bound = record_rectangle_pos[0]
                right_bound = record_rectangle_pos[0] + record_rectangle_pos[2]
                up_bound = record_rectangle_pos[1]
                down_bound = record_rectangle_pos[1] + record_rectangle_pos[3]
                if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
                    bool_recording = False
                    bool_balance_result = True
                    #bool_results_menu = True
                    t_delay_results = pygame.time.get_ticks()
                    get_sensor_data(root, f"{file_name}_recording")
                    
            elif bool_balance_result == True:
                left_bound = other_results_rectangle_pos[0]
                right_bound = other_results_rectangle_pos[0] + other_results_rectangle_pos[2]
                up_bound = other_results_rectangle_pos[1]
                down_bound = other_results_rectangle_pos[1] + other_results_rectangle_pos[3]
                if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
                    bool_balance_result = False
                    bool_results_menu = True
                
                    
            elif bool_results_menu == True: 
                
                elipsis_los_rectangle_pos = [390, 230, 500, 60]
                com_displacement_time_rectangle_pos = [390, 300, 500, 60]
                com_displacement_top_view_rectangle_pos = [390, 370, 500, 60]
                emg_plot_rectangle_pos = [390, 440, 500, 60]
                roll_and_pitch_rectangle_pos = [390, 510, 500, 60]

                
                left_bound = elipsis_los_rectangle_pos[0]
                right_bound = elipsis_los_rectangle_pos[0] + elipsis_los_rectangle_pos[2]
                height_delta = 60
                height = elipsis_los_rectangle_pos[1]
                stop = False
                count = 0
                while stop == False and height < roll_and_pitch_rectangle_pos[1]:
                    if height < mouse_pos[1] < height + height_delta:
                        results_bools[count] = True
                        bool_results_menu = False
                        stop = True
                        show_plot = True
                    else:
                        height += height_delta + 10
                        count += 1                
                        if count == 4:
                            results_bools[count] = True
                            bool_results_menu = False
                            show_plot = True
                    
            elif show_plot == True:
                left_bound = back_rectangle_pos[0]
                right_bound = back_rectangle_pos[0] + back_rectangle_pos[2]
                up_bound = back_rectangle_pos[1]
                down_bound = back_rectangle_pos[1] + back_rectangle_pos[3]
                if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
                    show_plot = False
                    bool_results_menu = True
                    
                
            
                    
                
                
                    
        if event.type == pygame.KEYDOWN:
            if bool_starting_session == True and pygame.time.get_ticks() > t_delay + 100:
                text = input_texts[box_count]
                if event.key == pygame.K_RETURN:
                    box_count += 1
                    changed = False
                    t_delay = pygame.time.get_ticks() 
                    if box_count == 4:
                        bool_starting_session = False
                        bool_recording_menu = True
                        file_name = f"{input_texts[0]}"
                    
                elif event.key == pygame.K_BACKSPACE:
                    text = text[:-1]
                    input_texts[box_count] = text
                else:
                    if changed == False and event.key != pygame.K_RSHIFT and event.key != pygame.K_LSHIFT: 
                        text = ''
                        changed = True
                    text += event.unicode    
                    input_texts[box_count] = text
            if bool_calibrating_1 == True:
                if event.key == pygame.K_RETURN:
                    changed = False
                    bool_calibrating_1 = False
                    bool_calibrating_2 = True
                    
                elif event.key == pygame.K_BACKSPACE:
                    input_height_text = input_height_text[:-1]
                    
                else:
                    if changed == False and event.key != pygame.K_RSHIFT and event.key != pygame.K_LSHIFT: 
                        input_height_text = ''
                        changed = True
                    input_height_text += event.unicode 
        
                                
                    
    if bool_main == True:
        
        
        white_background_rectangle = [40, 40, 1280-80, 720-80]
        
        pygame.draw.rect(screen, white, white_background_rectangle, border_radius = 30)
        
        screen.blit(equilisense, equilisense_pos)
        
        
        angle_phase += rotation_speed * dt * 2 * math.pi  # full sine cycle over time
        angle = angle_amplitude * math.sin(angle_phase)
        
        rotated_logo = pygame.transform.rotozoom(logo, angle, 1)
       
        
        # Draw
        screen.blit(rotated_logo, logo_pos)
        
        #screen.blit(logo, logo_pos)
        
        screen.blit(background_blank, background_blank_pos)
        
        pygame.draw.rect(screen, main_blue, blue_background_rectangle)
        #screen.blit(background_main, background_main_pos)
        pygame.draw.rect(screen, main_blue, button_1_position, border_radius = main_border_radius)
        screen.blit(button_1_text, button_1_text_pos)
        left_bound = button_1_position[0]
        right_bound = button_1_position[0] + button_1_position[2]
        up_bound = button_1_position[1]
        down_bound = button_1_position[1] + button_1_position[3]

        if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
            inside_button = True 
        else:
            inside_button = False
        
        
    elif bool_starting_session == True:
        inside_button = False
        screen.blit(background_default, background_default_pos)
        pygame.draw.rect(screen, main_blue, blue_rectangle_pos, border_radius = main_border_radius)
        screen.blit(info_title_text, info_title_text_pos)
        
        for i in range(len(input_boxes)):
            pygame.draw.rect(screen, white, input_boxes[i], border_radius = main_border_radius)
            input_text = info_text_font.render(input_texts[i],True,"BLACK")
            screen.blit(input_text, (input_boxes[i][0]+5,input_boxes[i][1]+12))   
            
    elif bool_recording_menu == True:
        
        #Measure height of lumbar sensor
        #30 seconds standing still
        #Limits of stability
        
        screen.blit(background_default, background_default_pos)
        
        if calibrated == False:
            pygame.draw.rect(screen, main_blue, calibration_rectangle_pos, border_radius = main_border_radius)
            screen.blit(calibration_text, calibration_text_pos)    
            pygame.draw.rect(screen, transparent_blue, recording_rectangle_pos, border_radius = main_border_radius)
            screen.blit(recording_text, recording_text_pos)
            
        else:
            pygame.draw.rect(screen, main_blue, calibration_rectangle_pos, border_radius = main_border_radius)
            screen.blit(rep_calibration_text, rep_calibration_text_pos)    
            pygame.draw.rect(screen, main_blue, recording_rectangle_pos, border_radius = main_border_radius)
            screen.blit(recording_text, recording_text_pos)
            
        
        left_bound_cal = calibration_rectangle_pos[0]
        right_bound_cal = calibration_rectangle_pos[0] + calibration_rectangle_pos[2]
        up_bound_cal = calibration_rectangle_pos[1]
        down_bound_cal = calibration_rectangle_pos[1] + calibration_rectangle_pos[3]
        
        left_bound_rec = recording_rectangle_pos[0]
        right_bound_rec = recording_rectangle_pos[0] + recording_rectangle_pos[2]
        up_bound_rec = recording_rectangle_pos[1]
        down_bound_rec = recording_rectangle_pos[1] + recording_rectangle_pos[3]
        
        
        if left_bound_cal < mouse_pos[0] < right_bound_cal and up_bound_cal < mouse_pos[1] < down_bound_cal:
            inside_button = True 
            
        elif left_bound_rec < mouse_pos[0] < right_bound_rec and up_bound_rec < mouse_pos[1] < down_bound_rec and calibrated == True:
            inside_button = True
        
        else:
            inside_button = False
            
    elif bool_calibrating_1 == True:
        inside_button = False
        screen.blit(background_default, background_default_pos)
        
        screen.blit(lumbar_region, lumbar_region_pos)
        
        pygame.draw.rect(screen, main_blue, height_title_rec, border_radius = main_border_radius)
        
        screen.blit(height_title_text, height_title_pos)
        screen.blit(height_desc_text, height_desc_pos)
        
        pygame.draw.rect(screen, white, input_height_box, border_radius = main_border_radius)
       
        input_height_to_render = info_text_font.render(input_height_text + " (cm)", True, "Black")
        screen.blit(input_height_to_render, (input_height_box[0]+5,input_height_box[1]+12))   
        
        
        
    elif bool_calibrating_2 == True:
        inside_button = False
        screen.blit(background_default, background_default_pos)
        
        screen.blit(standing, standing_pos)
        
        
        pygame.draw.rect(screen, main_blue, standing_title_rec, border_radius = main_border_radius)
        screen.blit(standing_title_text, standing_title_pos)
        
        
        screen.blit(instructions_title_text, instructions_title_pos)
        #screen.blit(instructions_text, instructions_text_pos) 
    
        pygame.draw.rect(screen, main_blue, start_calibration_button, border_radius = main_border_radius)
        screen.blit(start_calibration_text, start_calibration_text_pos)
        
        for i in range(len(instructions)):
            instructions_text = height_desc_font.render(instructions[i], True, 'Black')
            instructions_text_pos = pygame.Vector2(100, 330 + i*40)
            screen.blit(instructions_text, instructions_text_pos) 
            
        
        left_bound = start_calibration_button[0]
        right_bound = start_calibration_button[0] + start_calibration_button[2]
        up_bound = start_calibration_button[1]
        down_bound = start_calibration_button[1] + start_calibration_button[3]
        
        
        
        if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
            inside_button = True 
        else:
            inside_button = False
            
        
        
        
    elif bool_calibrating_3 == True:
        
        
        
        inside_button = False
        screen.blit(background_default, background_default_pos)
        
        pygame.draw.rect(screen, main_blue, limits_of_stability_rec, border_radius = main_border_radius)
        screen.blit(limits_of_stability_text, limits_of_stability_text_pos)
        
        
        pygame.draw.rect(screen, main_blue, start_calibration_button, border_radius = main_border_radius)
        screen.blit(start_calibration_text, start_calibration_text_pos)
        
        
        screen.blit(limits_of_stability, limits_of_stability_pos)
        
        screen.blit(instructions_title_text, instructions_title_pos)
        #screen.blit(instructions_text, instructions_text_pos) 
    
        pygame.draw.rect(screen, main_blue, start_calibration_button, border_radius = main_border_radius)
        screen.blit(start_calibration_text, start_calibration_text_pos)
        
        for i in range(len(instructions_standing)):
            instructions_text = height_desc_font.render(instructions_standing[i], True, 'Black')
            instructions_text_pos = pygame.Vector2(100, 330 + i*40)
            screen.blit(instructions_text, instructions_text_pos) 
        
        left_bound = start_calibration_button[0]
        right_bound = start_calibration_button[0] + start_calibration_button[2]
        up_bound = start_calibration_button[1]
        down_bound = start_calibration_button[1] + start_calibration_button[3]
        
        if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
            inside_button = True 
        else:
            inside_button = False
            
    
    elif bool_recording == True:
        inside_button = False
        screen.blit(background_default, background_default_pos)
        
        pygame.draw.rect(screen, main_blue, recording_title_rec, border_radius = main_border_radius)
        screen.blit(recording_title_text, recording_title_pos)
        
        screen.blit(start_recording_text, start_recording_text_pos)
        
        pygame.draw.rect(screen, main_blue, record_rectangle_pos, border_radius = main_border_radius)

        screen.blit(record_button_text, record_button_pos)   
        
        left_bound = record_rectangle_pos[0]
        right_bound = record_rectangle_pos[0] + record_rectangle_pos[2]
        up_bound = record_rectangle_pos[1]
        down_bound = record_rectangle_pos[1] + record_rectangle_pos[3]
        if left_bound < mouse_pos[0] < right_bound and up_bound < mouse_pos[1] < down_bound:
            inside_button = True
        else:
            inside_button = False
            
    elif bool_balance_result == True:
        
        screen.blit(background_default, background_default_pos)
        
        screen.blit(balance_score, balance_score_pos)
    
        pygame.draw.rect(screen, main_blue, other_results_rectangle_pos, border_radius=main_border_radius)
        
        screen.blit(other_results_button_text, other_results_button_pos)
    
    
    elif bool_results_menu == True:
        
        inside_button = False
        screen.blit(background_default, background_default_pos)  
        
        #if got_results == False and pygame.time.get_ticks() < t_delay_results + 50:
            
        
        if got_results == False and pygame.time.get_ticks() > t_delay_results + 50:
            baseline_trials = [f"wavex_{file_name}_standing_stability.csv"]  # quiet standing filenames
            los_trials = [f"wavex_{file_name}_limits_of_stability.csv"]  # limits of stability filenames
            test_trials = [f"wavex_{file_name}_recording.csv"]  # trial to evaluate
            
            get_emg_signal()
            csv_root = root + r"\waveX ddl"
            
            results_df = analyze_trials(csv_root, baseline_trials, los_trials, test_trials, sensor_id=2)
            get_emg_signal(csv_root)
            
            
            print("\n=== Threshold Exceedance Results ===")
            print(results_df)
            got_results = True
            
        elif got_results == True and show_plot == False:
            
            pygame.draw.rect(screen, main_blue, elipsis_los_rectangle_pos, border_radius = main_border_radius)
            screen.blit(elipsis_los_text, elipsis_los_text_pos)    
            
            pygame.draw.rect(screen, main_blue, com_displacement_time_rectangle_pos, border_radius = main_border_radius)
            screen.blit(com_displacement_time_text, com_displacement_time_text_pos)    
            
            pygame.draw.rect(screen, main_blue, com_displacement_top_view_rectangle_pos, border_radius = main_border_radius)
            screen.blit(com_displacement_top_view_text, com_displacement_top_view_text_pos)    
            
            pygame.draw.rect(screen, main_blue, emg_plot_rectangle_pos, border_radius = main_border_radius)
            screen.blit(emg_plot_text, emg_plot_text_pos)    
            
            pygame.draw.rect(screen, main_blue, roll_and_pitch_rectangle_pos, border_radius = main_border_radius)
            screen.blit(roll_and_pitch_text, roll_and_pitch_text_pos)    
            
    elif show_plot == True:
        screen.blit(background_default, background_default_pos)
        
        image_to_plot = results_menu_plots[count]
        image_to_plot_pos = results_menu_plots_pos[count]
        
        #print(image_to_plot, image_to_plot_pos)
        
        screen.blit(image_to_plot, image_to_plot_pos)
        
        pygame.draw.rect(screen, main_blue, back_rectangle_pos, border_radius= main_border_radius)
        screen.blit(back_text, back_text_pos)
    
    
    
    
    if inside_button == True:
        pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_HAND)
    else:
        pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_ARROW)
        
        

    # RENDER YOUR GAME HERE

    # flip() the display to put your work on screen
    pygame.display.flip()

    dt = clock.tick(60) / 1000  # limits FPS to 60

pygame.quit()