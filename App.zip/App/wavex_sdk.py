import os, sys, time, csv, threading
from datetime import datetime
from pathlib import Path


def get_sensor_data(root, file_name):
    
    # Folder DIR with the DLL's
    
    #root = r"C:\Users\Utilizador\Documents\Pedro\Universidade\5 Ano - 1 Semestre\DDM\Challenge"
    DLL_DIR = root + r"\waveX ddl"
    
    #DLL_DIR = r"C:\Users\loure\Desktop\uni\5 Ano\DDM\waveX ddl"                           #CHANGE
    #OUT_DIR = Path("./wxdumps"); 
    OUT_DIR = DLL_DIR                         #CHANGE
    #in case of not existing it creates
    OUT_DIR.mkdir(exist_ok=True)
    
    #because my pythonnet version is > 3.0
    from pythonnet import load
    load("netfx")
    import clr
    
    # DDL'S into python
    os.environ["PATH"] = DLL_DIR + os.pathsep + os.environ.get("PATH", "")
    sys.path.append(DLL_DIR)
    for asm in ("WaveX.Common", "WaveX.Sys", "PicoBlue.DaqSys", "WaveX"):
        clr.AddReference(asm)
    
    from WaveX import DaqSystem
    from WaveX.Common.Definitions import (
        CaptureConfiguration,
        DataAvailableEventPeriod,
        DeviceState,
        EmgImuAcqXType,
    )
    from WaveX.Common.Definitions import SensorConfiguration, SensorMode, AccelerometerFullScale, GyroscopeFullScale
    
    
    # ---------- HELPER: build header ----------
    def build_header(sensor_labels):
        hdr = ["Time(s)"]
        # EMG
        for lab in sensor_labels:
            hdr.append(f"Emg_{lab}(µV)")
        # ACC
        for axis in ("X","Y","Z"):
            for lab in sensor_labels:
                hdr.append(f"Imu_{lab}_ImuAcc:{axis}(g)")
        # GYR
        for axis in ("X","Y","Z"):
            for lab in sensor_labels:
                hdr.append(f"Imu_{lab}_ImuGyro:{axis}(D/s)")
        # MAG
        for axis in ("X","Y","Z"):
                for lab in sensor_labels:
                    hdr.append(f"Imu_{lab}_ImuMag:{axis}(µT)")
        return hdr
    
    # ---------- MAIN RECORDER ----------
    """def record_csv(
        duration_s,
        sensor_labels,
        emg_mode,
        imu_mode,
        emg_rate_hz,
        imu_rate_hz,
        period,
        out_path: str | None = None,
    ):"""
    
    
    def record_csv(
        sensor_labels,
        out_path: str | None = None,
    ):
        
        duration_s = 30;
        emg_rate_hz = 2000;
        period = DataAvailableEventPeriod.ms_100;
    
    
        daq = DaqSystem()
    
        state = daq.State;
        print(state)
        if state != DeviceState.Idle:
            raise RuntimeError(f"Device not ready. State={state}")
    
        # Sensor mode
        sc = SensorConfiguration()
        sc.SensorMode = SensorMode.EMG_INERTIAL_SENSOR
        
        # Scales
        sc.AccelerometerFullScale = AccelerometerFullScale.g_8     
        sc.GyroscopeFullScale = GyroscopeFullScale.dps_1000
        
        daq.DisableSensor(0)
        for sid in sensor_labels:
            daq.EnableSensor(sid)
            daq.ConfigureSensor(sc, sid)
    
        # Configure acquisition
        cfg = CaptureConfiguration()
        cfg.EMG_IMU_AcqXType = EmgImuAcqXType.Emg_2kHz_RawAccGyroMagData_100Hz
        daq.ConfigureCapture(cfg)
    
        # Calibration
        print("Calibrating IMU offsets... keep sensors still")
        for sid in sensor_labels:
            daq.DetectAccelerometerOffset(sid)
            daq.CalibrateSensorImuOffset(sid)
            daq.CalibrateGyroscopeOffset(sid)
        print("Calibration done.")
    
    
    
        # Output file
        if out_path is None:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            out_path = str(OUT_DIR / f"wavex_{file_name}.csv")
    
        f = open(out_path, "w", newline="")
        w = csv.writer(f)
    
        # If magnetometer is not provided by the device/mode, we will drop those columns on first callback
        include_mag = True
        header_written = False
    
        emg_abs = 0
        #emg_rate_hz = 2000;
        emg_dt = 1.0 / float(emg_rate_hz)
    
        stop_flag = threading.Event() #Creates a threading event python object
        start_t = time.time() # Creates a threading event object
    
        def on_data(sender, e):
            """
            sender - The object that raised the event, i.e., the DaqSystem instance.
            e - actual sensor data arrays - instance of the .NET class DataAvailableEventArgs pg.20 
            """
            nonlocal header_written, include_mag, emg_abs#, imu_abs
    
    
            # Stop on duration
            if time.time() - start_t >= duration_s:
                stop_flag.set() # tells worker threads to stop
                return
    
            # python function, same of doing sdk function e.EmgSamples
            emg = getattr(e, "EmgSamples", None)
            acc = getattr(e, "AccelerometerSamples", None) 
            gyr = getattr(e, "GyroscopeSamples", None)
            mag = getattr(e, "MagnetometerSamples", None)
            
            # int(e.ScanNumber) not used less robust
            emg_scan = emg.GetLength(1) 
            acc_scan = acc.GetLength(2) 
            gyr_scan = gyr.GetLength(2) 
            mag_scan = mag.GetLength(2)
    
            
            #some safety checks
            if acc_scan != gyr_scan or acc_scan != mag_scan:
                print("IMU with different sizes") 
    
            if acc_scan != emg_scan:
                print("IMU and EMG with different sizes") 
    
            if e.EmgSamples != emg:
                print("EMG bad extracted")
    
            if emg.GetLength(0) != acc.GetLength(0):
                print("different number of indexes (len(emg[0])!=len(acc[0]))")
    
            for i in range(emg.GetLength(0)):
                if acc[i,0,0] != 0.0:
                    if i+1 not in sensor_labels:
                        print("Reading not matching with required sensors")
            for i in range(emg.GetLength(0)):
                if mag[i,0,0] != 0.0:
                    if i+1 not in sensor_labels:
                        print("Reading not matching with required sensors")
            
            """
            # Battery check
            n_slots = daq.InstalledSensors
            states = e.SensorStates  # returns a list or array of shorts
            for i in sensor_labels:
                print(f"Sensor {i}: state = {states[i-1]}")
            """
        
            if not header_written:
                w.writerow(build_header(sensor_labels))
                header_written = True
    
            # one row per EMG sample, EMG has the same size as the rest
            for k in range(emg_scan):
    
                n_emg = emg_abs + k
                t = n_emg * emg_dt
                row = [f"{t:.7f}"]
    
                # EMG columns
                if emg is not None:
                    for s in sensor_labels:
                        row.append(float(emg[s-1, k]))
                   
                # ACC 
                n_sensors_acc = None
                if acc is not None:
                    for axis in (0,1,2):
                        for s in sensor_labels:
                            row.append(float(acc[s-1,axis,k]))
    
                # GYR 
                if gyr is not None:
                    for axis in (0,1,2):
                        for s in sensor_labels:
                            row.append(float(gyr[s-1,axis,k]))
    
                # MAG
                if mag is not None:
                        for axis in (0,1,2):
                            for s in sensor_labels:
                                row.append(float(mag[s-1,axis,k]))
    
    
                w.writerow(row)
            emg_abs  = n_emg;
    
    
        # Hook + start
        daq.DataAvailable += on_data  #Hook
        daq.StartCapturing(period)
        print(daq.State)
        try:
            while not stop_flag.is_set():
                time.sleep(0.01)
        finally:
            daq.StopCapturing()
            try:
                daq.DataAvailable -= on_data
            except Exception:
                print("Exception occurred")
                pass
            f.close()
    
        return out_path
    
    
    # ---------- Input ----------
    if __name__ == "__main__":
    
        labels = (1,2,3,4,5,6)
    
        # for testing I define the variables inside the functions to easier fixing  
        """
        path = record_csv(
            duration_s=30,
            sensor_labels=labels,
            emg_mode=None,
            imu_mode=None,
            emg_rate_hz=None,
            imu_rate_hz=None,
            period=DataAvailableEventPeriod.ms_100
        )
        """
        path = record_csv(
            sensor_labels=labels
        ) 
    
        print("Saved:", path)
